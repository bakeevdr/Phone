<?php 
	// Версия от 2016-04-02

	$LDAPCurent = '';
	$UnitCurent	= '';
	if (isset($_POST['loginLDAP']) && (trim($_POST['loginLDAP'])!='') && isset($_POST['passwordLDAP']) && (Trim($_POST['passwordLDAP'])!='')&& (isset($_POST['KR'])) && (trim($_POST['KR'])!='') ) {
		require_once("../config.php");
		function setData($LC, $DN, $info) {
			$LD_Mod = array();
			$LD_Del = array();
			foreach($info as $k=>$v) {
				if ($v == '')
					$LD_Del[$k]=array();
				$LD_Mod[$k]='-';
				If ((is_array($v)) && (Count($v) !=0 ))
					$LD_Mod[$k]=$v;
				Elseif (!(is_array($v)) && ($v != ''))
						$LD_Mod[$k]=Trim($v);
			}
			if (count ($LD_Mod) != 0)
				ldap_modify($LC, $DN, $LD_Mod);
			if (count ($LD_Del) != 0)
				ldap_mod_del($LC, $DN, $LD_Del);
		}
		$LDAPCurent		= 	$_POST['KR'];
		$UnitCurent  	= 	$_POST['OU'];
		If (isset($P_LDAP[$LDAPCurent])) {
			$LC			=	ldap_connect($P_LDAP[$LDAPCurent]['Server'][0],'389');
			ldap_set_option($LC, LDAP_OPT_PROTOCOL_VERSION, 3); 
			ldap_set_option($LC, LDAP_OPT_REFERRALS, 0); 
			If (@ldap_bind($LC, $_POST['loginLDAP'].substr($P_LDAP[$LDAPCurent]['User'],strpos($P_LDAP[$LDAPCurent]['User'],'@'),100), $_POST['passwordLDAP'])===True) {	
				$LS			=	ldap_search(	$LC, 
												(!empty($UnitCurent)?"OU=$UnitCurent, ":'').$P_LDAP[$LDAPCurent]['DC'] , 
												"(&(cn=".trim($_POST['TestCN'])."*)(sAMAccountType=805306368)(!(useraccountcontrol:1.2.840.113556.1.4.803:=2))(!(useraccountcontrol:1.2.840.113556.1.4.803:=16))(!(description=@*)))", 
												array('otherpager', 'otheripphone'),
												0,
												0);
				$ArrData	=	ldap_get_entries($LC, $LS);
				unset ($ArrData['count']);
			}
			Else 
				Echo 'Неправильная пара ЛОГИН и ПАРОЛЬ <BR><BR><BR>';
		}
	}
	$Title ="Замена 'прочие' поля Pager и IPPhone ";
?>
<html>
	<head>
		<title><?php Echo $Title?></title>
		<meta charset="utf-8">
	</head>
	<body>
		<Style>
			dl{
				margin-bottom: 0px;
			}
			dd{
				margin-left: 200px;
			}
			dt {
				float: left;
				width: 180px;
			}
		</Style>
		<B><?php Echo $Title?></b><br><br>
		<B><i>Для использования утилиты заполните поля</b></i><br>
		<form name="FormPassIRGKN" method="post" action="">
			<dl>
				<dt>Номер региона*		</dt><dd><input type="text" 	name="KR"  value="<?php Echo $LDAPCurent ?>" size="30"></dd>
				<dt>Дополнительный OU	</dt><dd><input type="text" 	name="OU"  value="<?php Echo $UnitCurent ?>" size="30" Value='0'></dd>
				<dt>Логин*				</dt><dd><input type="text" 	name="loginLDAP"  value="" size="30"></dd>
				<dt>Пароль*				</dt><dd><input type="password"	name="passwordLDAP"  value="" size="30"></dd>
				<dt>&nbsp;				</dt><dd>&nbsp;</dd>
				<dt>Тестовый запуск 	</dt><dd><input type="checkbox"	name="TestRun" <?php Echo (!Empty($_POST['TestRun'])?'checked="checked"':'')?> size="30"></dd>
				<dt>Искать CN			</dt><dd><input type="text" 	name="TestCN"  value="<?php Echo (!Empty($_POST['TestCN'])?$_POST['TestCN']:'')?>" size="30"></dd>
				<dt>&nbsp;				</dt><dd>&nbsp;</dd>
				<dt>&nbsp;				</dt><dd><input type="submit" value="Выполнить"></dd>	
			</dl>
		</form>
		<?php 
			if (empty($ArrData)) {
				if (!empty($LDAPCurent)) 
					Echo 'Записей не найдено';
			}
			Else {
				$RP='Обработка';
				foreach($ArrData as $ar_Rows) {	
					$_pager		= array();
					$_ipphone	= array();
					$ArrCur=array();
					if (isset($ar_Rows['otherpager'])) {
						unset($ar_Rows['otherpager']['count']);
						$_pager	=	$ar_Rows['otherpager'];
					};
					if (isset($ar_Rows['otheripphone'])) {
						unset($ar_Rows['otheripphone']['count']);
						$_ipphone	=	$ar_Rows['otheripphone'];
					};
					$ArrCur['otherpager'] = '';
					$ArrCur['otheripphone'] = array_merge($_pager, $_ipphone);
					If (!empty($ArrCur) ) {
						Echo '<pre>';
						Echo Print_r($ar_Rows);
						Echo '<br>';
						Echo Print_r($ArrCur);
						Echo '</pre>';
						Echo '=====================================================================================';
						if (Empty($_POST['TestRun']))
							setData($LC, $ar_Rows['dn'], $ArrCur);
					}
				};/**/
				Echo '<br>ВСЁ ГОТОВО';
			};
		?>
	<?php echo base64_decode ('PGRpdiBzdHlsZT0iZm9udC1mYW1pbHk6IHNlcmlmOyBmb250LXNpemU6IDEycHg7IGJhY2tncm91bmQtY29sb3I6IGFsaWNlYmx1ZTsgYm9yZGVyOiAxcHggb3V0c2V0OyBib3R0b206IDVweDsgY3Vyc29yOiBkZWZhdWx0OyBtYXJnaW4tbGVmdDogMHB4OyBwYWRkaW5nOiAzcHggNnB4OyByaWdodDogMjRweDsgcG9zaXRpb246IGFic29sdXRlOyI+IFBvd2VyZWQgYnkg0JHQsNC60LXQtdCyINCU0KAgPC9kaXY+');?>	
	</body>
</html>