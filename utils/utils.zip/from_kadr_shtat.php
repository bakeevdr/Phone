<?php 
	//error_reporting(0); 
	set_time_limit(0);
	require_once("../config.php");
	require_once(".../ldaps.php");
	$Title ="Обновление LDAP из EXCEL";
	$LDAPCon=new LDAP($P_LDAP['KO']['Server'], $P_LDAP['KO']['User'], $P_LDAP['KO']['Pass']);
	require_once "PHPExcel.php";
	
	$objReader = PHPExcel_IOFactory::createReader('Excel2007');
	$objPHPExcel = $objReader->load('!Shtat20150812.xlsx');
	$ArrXLS = $objPHPExcel->getActiveSheet()->toArray();
	
	mb_internal_encoding("UTF-8");
	
			foreach($ArrXLS as $ar_Rows) {
			//Echo Print_r($ar_Rows).'<br>';
		};
?>

<html>
	<head>
		<title><?php Echo $Title?></title>
		<meta charset="utf-8">
	</head>
	<body>
<?PHP
	foreach($ArrXLS as $ar_Rows) {
		$RP='Обработка';
		$CurUserDN = '';
		$ArrCur=array();
		$FindUser = $ar_Rows[1];
		$FindUser = str_replace(' ДО','',$FindUser);
		$FindUser = str_replace('ДО','',$FindUser);
		$FindUser = strpos($FindUser,'(')?substr($FindUser,'0',strpos($FindUser,'(')):$FindUser;
		$FindUser = str_replace('  ',' ',$FindUser);
		$FindUser = Trim($FindUser);
		if ($ar_Rows[1]!='') {
			@$CurUserDN = $LDAPCon->getArray($P_LDAP['02']['OU'], 
					"(&(cn=*$FindUser)(sAMAccountType=805306368)(!(useraccountcontrol:1.2.840.113556.1.4.803:=2))(!(useraccountcontrol:1.2.840.113556.1.4.803:=16))(!(description=@*)))",
					array('title'));
			$ArrCur['company']	=	'Филиал ФГБУ "ФКП Росреестра" по РБ';
			$ArrCur['title']	=	trim($ar_Rows[0]);
			$RP='Не найден в АД';
			If (count($CurUserDN)==1) {
				$RP='Найден в АД';
				if (@$CurUserDN[0]['title']!=$ar_Rows[0]) {
				$RP='Обновлена запись';
				$LDAPCon->setData($CurUserDN[0]['dn'], $ArrCur);
				}
			}
		}
		Echo $RP.'|';
		Echo (($FindUser!='')?$FindUser:'-').'|';
		Print_r($ArrCur);
		Echo '<br>';
	};
?>
<?php echo base64_decode ('PGRpdiBzdHlsZT0iZm9udC1mYW1pbHk6IHNlcmlmOyBmb250LXNpemU6IDEycHg7IGJhY2tncm91bmQtY29sb3I6IGFsaWNlYmx1ZTsgYm9yZGVyOiAxcHggb3V0c2V0OyBib3R0b206IDVweDsgY3Vyc29yOiBkZWZhdWx0OyBtYXJnaW4tbGVmdDogMHB4OyBwYWRkaW5nOiAzcHggNnB4OyByaWdodDogMjRweDsgcG9zaXRpb246IGFic29sdXRlOyI+IFBvd2VyZWQgYnkg0JHQsNC60LXQtdCyINCU0KAgPC9kaXY+');?>	
	</body>
</html>