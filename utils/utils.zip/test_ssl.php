<?php
//  http://ru.overcram.com/questions/4343684/%D0%9F%D1%80%D0%BE%D1%82%D0%BE%D0%BA%D0%BE%D0%BB-LDAP-%D0%BD%D0%B5-%D0%BC%D0%BE%D0%B3%D1%83-%D0%BF%D1%80%D0%B8%D0%B2%D1%8F%D0%B7%D0%B0%D1%82%D1%8C-%D1%81%D0%B5%D1%80%D0%B2%D0%B5%D1%80-%D0%BF%D0%BE%D1%81%D0%BB%D0%B5-%D0%B2%D0%BA%D0%BB%D1%8E%D1%87%D0%B5%D0%BD%D0%B8%D1%8F-%D1%82%D1%80%D0%B5%D0%B1%D0%BE%D0%B2%D0%B0%D0%BD%D0%B8%D1%8F-%D0%9F%D0%BE%D0%B4%D0%BF%D0%B8%D1%81%D1%8B%D0%B2%D0%B0%D0%BD%D0%B8%D1%8F-%D0%B4
//	 ldapsearch -D TelPhone@reg.gkn.cor -w "#FwO*sdhjz?niRiNo*=/Q(V" -LLL -h 10.41.143.225 -b DC=reg,DC=gkn,DC=cor -P 3 cn -z 10
//	 ldapsearch -D TelPhone@kpl.local -w "Qwerty28" -LLL -h 10.28.143.211 -b DC=kpl,DC=local -P 3 cn -z 10

	/*$DN		= 'CN=Users, DC=reg, DC=gkn, DC=cor';
	$Server = '10.41.143.225';
	$Port 	= '389';
	$User 	= 'CN=TelPhone,CN=Users,DC=reg,DC=gkn,DC=cor';
	$Password = '#FwO*sdhjz?niRiNo*=/Q(V'; /**/
	
	/*$DN		= 'DC=zkprb, DC=local';
	$Server = '10.2.143.19';
	$Port 	= '389';
	$User 	= 'CN=TelPhone,OU=!Тел справочник,OU=Ufa,OU=FGU ZKP,DC=zkprb,DC=local';
	$Password = 'r53dn98wtv3gyn80gvhp89ty0*(^78g'; /**/

	$DN		= 'DC=kpl,DC=local';	
	$Server = 'ldaps://10.28.143.211/';
	$Server = '10.28.143.211';
	$Port 	= 389;
	$User 	= 'CN=TelPhone,OU=Users_fgu28,DC=kpl,DC=local';
	$Password = ('Qwerty28'); /**/
	
	$LC=ldap_connect($Server,$Port);		
	ldap_set_option($LC, LDAP_OPT_PROTOCOL_VERSION, 3); 
	ldap_set_option($LC, LDAP_OPT_REFERRALS, 0); 
	ldap_start_tls($LC);
//	http://php.net/manual/ru/function.ldap-start-tls.php
//	ldap_sasl_bind ( $LC, NULL, $Password, 'DIGEST-MD5', NULL, $User);
	
	$LB_Read=ldap_bind($LC, $User, $Password); 
	$LS	=	ldap_search($LC, $DN, 
					"(&(sAMAccountType=805306368)(!(useraccountcontrol:1.2.840.113556.1.4.803:=2))(!(useraccountcontrol:1.2.840.113556.1.4.803:=16))(!(description=@*)))", 
					array('cn', 'dn')
			);
	$LE	=	ldap_get_entries($LC, $LS);
	foreach($LE as $w) {
		Echo $w['cn'][0].' ---====--- '.$w['dn'].' <br>';
	}
/**/	
  /*
        $ds=ldap_connect($Server,$Port);
        $r = ldap_search( $ds, $DN, "uid=$User");
        if ($r) {
            $result = ldap_get_entries( $ds, $r);
            if ($result[0]) {
                if (ldap_bind( $ds, $result[0]['dn'], $Password) ) {
                    return $result[0];
                }
            }
        }
 /**/
 
 
 
?>

