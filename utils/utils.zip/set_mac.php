<?php 
	// Версия от 07-12-2015
	//error_reporting(0); 
	$Title ="Установка заглушки (МАК, Модель) в поле 'otherpager'";
	$LDAPCurent = '';
	$UnitCurent	= '';
	if (isset($_POST['loginLDAP']) && (trim($_POST['loginLDAP'])!='') && isset($_POST['passwordLDAP']) && (Trim($_POST['passwordLDAP'])!='')&& (isset($_POST['KR'])) && (trim($_POST['KR'])!='') ) {
		require_once("../config.php");
		function setData($LC, $DN, $info) {
			$LD_Mod = array();
			$LD_Del = array();
			foreach($info as $k=>$v) {
				if ($v == '')
					$LD_Del[$k]=array();
				$LD_Mod[$k]='-';
				If ((is_array($v)) && (Count($v) !=0 ))
					$LD_Mod[$k]=$v;
				Elseif (!(is_array($v)) && ($v != ''))
						$LD_Mod[$k]=Trim($v);
			}
			if (count ($LD_Mod) != 0)
				ldap_modify($LC, $DN, $LD_Mod);
			if (count ($LD_Del) != 0)
				ldap_mod_del($LC, $DN, $LD_Del);
		}
		$LDAPCurent		= 	$_POST['KR'];
		$UnitCurent  	= 	$_POST['OU'];
		If (isset($P_LDAP[$LDAPCurent])) {
			$LC			=	ldap_connect($P_LDAP[$LDAPCurent]['Server'][0],'389');
			ldap_set_option($LC, LDAP_OPT_PROTOCOL_VERSION, 3); 
			ldap_set_option($LC, LDAP_OPT_REFERRALS, 0); 
			If (@ldap_bind($LC, $_POST['loginLDAP'], $_POST['passwordLDAP'])===True) {
				$LS			=	ldap_search(	$LC, 
												(!empty($UnitCurent)?"OU=$UnitCurent, ":'').$P_LDAP[$LDAPCurent]['DC'] ,
												"(&(cn=*)(sAMAccountType=805306368)(!(otherpager=*))(!(useraccountcontrol:1.2.840.113556.1.4.803:=2))(!(useraccountcontrol:1.2.840.113556.1.4.803:=16))(!(description=@*)))",
												array('otherpager'),
												0,
												0);
				$ArrData	=	ldap_get_entries($LC, $LS);		
				unset ($ArrData['count']);
			}
			Else 
				Echo 'Неправильная пара ЛОГИН и ПАРОЛЬ <BR><BR><BR>';
		}
	}
?>
<html>
	<head>
		<title><?php Echo $Title?></title>
		<meta charset="utf-8">
	</head>
	<body>
		<Style>
			dl{
				margin-bottom: 0px;
			}
			dt {
				float: left;
				width: 180px;
			}
		</Style>
	<?php if (empty($ArrData)) : ?>
		<B><?php Echo $Title?></b><br>
		<B><i>Для использования утилиты заполните поля</b></i><br>
		<form name="FormPassIRGKN" method="post" action="">
			<dl>
				<dt>Номер региона:</dt>		<dd><input type="text" name="KR" value="<?php Echo $LDAPCurent ?>" size="30"></dd>
				<dt>Дополнительный OU</dt>	<dd><input type="text" name="OU" value="<?php Echo $UnitCurent ?>" size="30"></dd>
				<dt>Логин:</dt>				<dd><input type="text" name="loginLDAP"  value="" size="30"></dd>
				<dt>Пароль:</dt>			<dd><input type="password" name="passwordLDAP"  value="" size="30"></dd>
			</dl>
			<input type="submit" value="Выполнить">
		</form>
	<?PHP
			Else :
				Echo 'Найдено записей для обработки : '.count($ArrData).'<br>';
				Echo '<br><br>';
				$ArrCur['otherpager']=array('МАК : ','Модель: ');/**/
				foreach($ArrData as $ar_Rows) {
					If (!isset($ar_Rows['otherpager']) ) {
						Print_r($ar_Rows);
						setData($LC, $ar_Rows['dn'], $ArrCur);
						Echo '<br>';
					}
				}
				Echo '<br>ВСЁ ГОТОВО';
			EndIf;
	?>
	<?php echo base64_decode ('PGRpdiBzdHlsZT0iZm9udC1mYW1pbHk6IHNlcmlmOyBmb250LXNpemU6IDEycHg7IGJhY2tncm91bmQtY29sb3I6IGFsaWNlYmx1ZTsgYm9yZGVyOiAxcHggb3V0c2V0OyBib3R0b206IDVweDsgY3Vyc29yOiBkZWZhdWx0OyBtYXJnaW4tbGVmdDogMHB4OyBwYWRkaW5nOiAzcHggNnB4OyByaWdodDogMjRweDsgcG9zaXRpb246IGFic29sdXRlOyI+IFBvd2VyZWQgYnkg0JHQsNC60LXQtdCyINCU0KAgPC9kaXY+');?>	
	</body>
</html>