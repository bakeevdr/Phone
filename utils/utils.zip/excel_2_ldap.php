<?php 
	//error_reporting(0); 
	require_once("../config.php");
	require_once("../ldaps.php");
	$Title ="���������� LDAP �� EXCEL";
	$LDAPCon=new LDAP($P_LDAP['KO']['Server'], $P_LDAP['KO']['User'], $P_LDAP['KO']['Pass']);
	require_once "PHPExcel.php";
	
	$objReader = PHPExcel_IOFactory::createReader('Excel2007');
	$objPHPExcel = $objReader->load('!Load2!.xlsx');
	$ArrXLS = $objPHPExcel->getActiveSheet()->toArray();
	
	mb_internal_encoding("UTF-8");
	
			foreach($ArrXLS as $ar_Rows) {
			//Echo Print_r($ar_Rows).'<br>';
		};
?>

<html>
	<head>
		<title><?php Echo $Title?></title>
		<meta charset="utf-8">
	</head>
	<body>
<?PHP
	$CurDep = '';
	$CurDepPhone = '';
	foreach($ArrXLS as $ar_Rows) {

		$CurUserDN = '';
		$ArrCur=array();
		if (($ar_Rows[0]=='') && ($ar_Rows[1]=='') && ($ar_Rows[2]!='')) {
			if (StrPos($ar_Rows[2],'+') != 0) {
				$CurDep = substr($ar_Rows[2],0,StrPos($ar_Rows[2],'+')+5);
				$CurDep = substr($ar_Rows[2],0,StrPos($ar_Rows[2],')')).')';
				$CurDepPhone = 		$phone = preg_replace('/[^0-9,+ ]/', '', substr($ar_Rows[2],StrPos($ar_Rows[2],'+'),120));
			} else 
			{
				$CurDep = $ar_Rows[2];
				$CurDepPhone = '';
			}
		}
		if ($ar_Rows[1]!='') {
			@$CurUserDN = $LDAPCon->getArray($P_LDAP['02']['OU'], 
					"(&(cn=*$ar_Rows[1])(sAMAccountType=805306368)(!(useraccountcontrol:1.2.840.113556.1.4.803:=2))(!(useraccountcontrol:1.2.840.113556.1.4.803:=16))(!(description=@*)))");
			If (count($CurUserDN)==1) {
				$ArrCur['department']=$CurDep;
				if (StrPos($ar_Rows[2],'+') != 0) 
					$ArrCur['telephonenumber']=preg_replace('/[^0-9,+ ]/', '', substr($ar_Rows[2],StrPos($ar_Rows[2],'+'),120));
				Else
					$ArrCur['telephonenumber']=$CurDepPhone;
				$ArrCur['physicaldeliveryofficename']=(isset($ar_Rows[0])?$ar_Rows[0]:'');
				if (strtolower($ar_Rows[3])!='нет')
					$ArrCur['ipphone']=$ar_Rows[3];
				Else 
					$ArrCur['ipphone']='';
				$ArrCur['company']='Филиал ФГБУ "ФКП Росреестра" по РБ';
				
				if (StrPos($ar_Rows[2],'+') != 0) 
					$ArrCur['title']=(isset($ar_Rows[0])?$ar_Rows[0]:'');
				Else
					$ArrCur['title']=$ar_Rows[2];
				$ArrCur['pager']=$ar_Rows[4];
				$ArrCur['otheripphone']=array('МАК : '.$ar_Rows[5],'Модель: '.$ar_Rows[7]);/**/
				If (($ArrCur['ipphone']!='')||($ArrCur['pager']!='')) {
					$LDAPCon->setData($CurUserDN[0]['dn'], $ArrCur);
					Print_r($ArrCur);
					Echo '<br>';
				}
			}
		}
	};
?>
<?php echo base64_decode ('PGRpdiBzdHlsZT0iZm9udC1mYW1pbHk6IHNlcmlmOyBmb250LXNpemU6IDEycHg7IGJhY2tncm91bmQtY29sb3I6IGFsaWNlYmx1ZTsgYm9yZGVyOiAxcHggb3V0c2V0OyBib3R0b206IDVweDsgY3Vyc29yOiBkZWZhdWx0OyBtYXJnaW4tbGVmdDogMHB4OyBwYWRkaW5nOiAzcHggNnB4OyByaWdodDogMjRweDsgcG9zaXRpb246IGFic29sdXRlOyI+IFBvd2VyZWQgYnkg0JHQsNC60LXQtdCyINCU0KAgPC9kaXY+');?>	
	</body>
</html>