<?php 
	// Версия 2016-04-02
	if (
		isset($_POST['loginLDAP']) 		&& (trim($_POST['loginLDAP'])!='') && 
		isset($_POST['passwordLDAP']) 	&& (Trim($_POST['passwordLDAP'])!='')&& 
		isset($_POST['IDLDAP']) 		&& (trim($_POST['IDLDAP'])!='') &&
		isset($_POST['Change_ipphone']) &&
		isset($_POST['Change_telephonenumber'])
		) {
		require_once("../config.php");
		// ============================================================================================
		function setData($LC, $DN, $info) {
			$LD_Mod = array();
			$LD_Del = array();
			foreach($info as $k=>$v) {
				if ($v == '')
					$LD_Del[$k]=array();
				$LD_Mod[$k]='-';
				If ((is_array($v)) && (Count($v) !=0 ))
					$LD_Mod[$k]=$v;
				Elseif (!(is_array($v)) && ($v != ''))
						$LD_Mod[$k]=Trim($v);
			}
			if (count ($LD_Mod) != 0)
				ldap_modify($LC, $DN, $LD_Mod);
			if (count ($LD_Del) != 0)
				ldap_mod_del($LC, $DN, $LD_Del);
		}
		// ============================================================================================
	function phone_format($phones,$Pref='', $Ncount=0){							// Форматирование телефона
		$phones = str_replace(';', ',', $phones);
		$phones = str_replace(':', ',', $phones);
		$phones = str_replace('+7', '8', $phones);
		$Phones = explode(',', $phones);
		$formats = array(	'5'		=>	'(##) ###',
							'7'		=>	'#(##) ####',
							'11'	=>	($Pref=='') ? '#(####) ##-##-##' : '#('.str_repeat("#", strlen($Pref)-1).') '. str_repeat("#", 7-strlen($Pref)) .'-##-##',
							'14'	=>	($Pref=='') ? '#(####) ##-##-##(###)' : '#('.str_repeat("#", strlen($Pref)-1).') '. str_repeat("#", 7-strlen($Pref)) .'-##-## (###)',
							'15'	=>	($Pref=='') ? '#(####) ##-##-##(####)' : '#('.str_repeat("#", strlen($Pref)-1).') '. str_repeat("#", 7-strlen($Pref)) .'-##-## (####)',
		);
		foreach($Phones as $H) {
			$phone = preg_replace('/[^0-9]/', '', $H);
			//$phone = ($Ncount!== 0)?substr($phone,$Ncount):$phone;
			if (
					($Pref !='')  				// Если есть префикс 
				&&	($Ncount !=0) 				// Если известно кол-во символов
				//&&	($Ncount !=strlen($phone))	// Если длина не равна длине строки 
				&&	(substr($phone,0,strlen($Pref))!==$Pref)				// если префиксы не совпадают 
				&&	($Ncount === strlen(substr($Pref.$phone,0,$Ncount)))	// если длина строки с префиксом равна 
				&&	(array_key_exists(strlen($Pref.$phone), $formats))		// Если длина с префиксом есть в массиве
			)
				$phone = $Pref.$phone;
			if (array_key_exists(strlen($phone), $formats)) {
				$format = $formats[strlen($phone)];
				$pattern = '/' . str_repeat('([0-9])?', substr_count($format, '#')) . '(.*)/';
				$counter=0;
				$format = preg_replace_callback(
					str_replace('#', '#', '/([#])/'),
					function () use (&$counter) {
						return '${' . (++$counter) . '}';
					},
					$format
				);
				$Result[] = ($phone ? trim(preg_replace($pattern, $format, $phone, 1)) : $H);
			}
			else
				$Result[] = $H;
		};
		return implode(",",$Result);
	}
		// ============================================================================================
		$LDAPCurent		= 	trim($_POST['IDLDAP']);
		$UnitCurent  	= 	trim($_POST['OU']);
		If (isset($P_LDAP[$LDAPCurent])) {
			$LC			=	ldap_connect($P_LDAP[$LDAPCurent]['Server'][0],'389');
			ldap_set_option($LC, LDAP_OPT_PROTOCOL_VERSION, 3); 
			ldap_set_option($LC, LDAP_OPT_REFERRALS, 0); 
			If (@ldap_bind($LC, $_POST['loginLDAP'].substr($P_LDAP[$LDAPCurent]['User'],strpos($P_LDAP[$LDAPCurent]['User'],'@'),100), $_POST['passwordLDAP'])===True) {
				$LS			=	@ldap_search(	$LC, 
												(!empty($UnitCurent)?"OU=$UnitCurent, ":'').$P_LDAP[$LDAPCurent]['DC'] , 
												"(&(cn=".trim($_POST['TestCN'])."*)(sAMAccountType=805306368)(!(useraccountcontrol:1.2.840.113556.1.4.803:=2))(!(useraccountcontrol:1.2.840.113556.1.4.803:=16))(!(description=@*)))",
												array('telephonenumber','ipphone', 'pager'),
												0,
												0);
				$ArrData	=	@ldap_get_entries($LC, $LS);
				unset ($ArrData['count']); 
			}
			Else 
				Echo 'Неправильная пара ЛОГИН и ПАРОЛЬ <BR><BR><BR>';
		}
	}
	$Title ="Нормализация телефонов: 'Номер телефона' (telephonenumber), 'IP номер' (ipphone), Пейджер (pager)";
?>
<html>
	<head>
		<title><?php Echo $Title?></title>
		<meta charset="utf-8">
	</head>
	<body>
		<Style>
			dl{
				margin-bottom: 0px;
			}
			dd{
				margin-left: 200px;
			}
			dt {
				float: left;
				width: 180px;
			}
		</Style>
		<B><?php Echo $Title?></b><br><br>
		<B><i>Для использования утилиты заполните поля</b></i><br>
		<form name="FormPassIRGKN" method="post" action="">
			<dl>
				<dt>ID LDAP (Регион) *	</dt><dd><input type="text" name="IDLDAP"  value="<?php Echo (!Empty($_POST['IDLDAP'])?$_POST['IDLDAP']:'')?>" size="30"></dd>
				<dt>Дополнительный OU	</dt><dd><input type="text" name="OU"  value="<?php Echo (!Empty($_POST['OU'])?$_POST['OU']:'')?>" size="30" Value='0'>Необходим в случае разделения в справочнике на ЦА и филиалы</dd> 
				<dt>Логин *				</dt><dd><input type="text" name="loginLDAP"  value="<?php Echo (!Empty($_POST['loginLDAP'])?$_POST['loginLDAP']:'')?>" size="30"></dd>
				<dt>Пароль *			</dt><dd><input type="password" name="passwordLDAP"  value="" size="30"></dd>
				<dt>&nbsp;				</dt><dd>&nbsp;</dd>
				<dt>Тестовый запуск 	</dt><dd><input type="checkbox" name="TestRun" <?php Echo (!Empty($_POST['TestRun'])?'checked="checked"':'')?> size="30"></dd>
				<dt>Искать CN			</dt><dd><input type="text" name="TestCN"  value="<?php Echo (!Empty($_POST['TestCN'])?$_POST['TestCN']:'')?>" size="30"></dd>
				<dt>&nbsp;				</dt><dd>&nbsp;</dd>
				<dt>Действие с 'Номер телефона' (telephonenumber)*</dt><dd>
						<input type="radio" name="Change_telephonenumber" value=""			<?php Echo ((Empty($_POST['Change_telephonenumber']))  	?'checked="checked"':'')?> >Пропустить </br>
						<input type="radio" name="Change_telephonenumber" value="normalize"	<?php Echo (!Empty($_POST['Change_telephonenumber']) && ($_POST['Change_telephonenumber']=='normalize')	?'checked="checked"':'')?> >Нормализация поля 'Номер телефона' (telephonenumber) </br>
						<input type="radio" name="Change_telephonenumber" value="pager"		<?php Echo (!Empty($_POST['Change_telephonenumber']) && ($_POST['Change_telephonenumber']=='pager'  )		?'checked="checked"':'')?> >Добавление поля Пейджер (pager) в 'Номер телефона' (telephonenumber)</br>
						<input type="radio" name="Change_telephonenumber" value="ipphone"	<?php Echo (!Empty($_POST['Change_telephonenumber']) && ($_POST['Change_telephonenumber']=='ipphone')		?'checked="checked"':'')?> >Добавление поля IP-телефон (ipphone) в 'Номер телефона' (telephonenumber)
											</dd>
				<dt>&nbsp;				</dt><dd>&nbsp;</dd>
				<dt>Действие с 'IP номер' (ipphone)*</dt><dd>
						<input type="radio" name="Change_ipphone" value=""			<?php Echo ((Empty($_POST['Change_ipphone']))  	?'checked="checked"':'')?> >Пропустить </br>
						<input type="radio" name="Change_ipphone" value="normalize"	<?php Echo (!Empty($_POST['Change_ipphone']) && ($_POST['Change_ipphone']=='normalize'	)?'checked="checked"':'')?> >Нормализация поля 'IP номер' (ipphone) </br>
						<input type="radio" name="Change_ipphone" value="pager"		<?php Echo (!Empty($_POST['Change_ipphone']) && ($_POST['Change_ipphone']=='pager'		)?'checked="checked"':'')?> >Добавление поля Пейджер (pager) в 'IP номер' (ipphone)
											</dd>
				<dt>Удалить Пейджер (pager)</dt><dd><input type="checkbox" name="Del_pager" <?php Echo (!Empty($_POST['Del_pager'])?'checked="checked"':'')?> size="30"></dd>
				<dt>&nbsp;				</dt><dd>&nbsp;</dd>
				<dt>&nbsp;				</dt><dd><input type="submit" value="Выполнить"></dd>	
			</dl>
		</form>
		<?php
			if (empty($ArrData)) {
				if (!empty($LDAPCurent)) {
					Echo 'Записей не найдено';
				}
			}
			Else {
				Echo 'Найдено записей для обработки : '.count($ArrData).'<br>';
				Echo '<br><br>';
				foreach($ArrData as $ar_Rows) {
					$ArrCur=array();
					
					if (!Empty($_POST['Change_telephonenumber']) && (isset($ar_Rows['telephonenumber'][0]))) {
						$ipphone_telephonenumber= 
								phone_format(
									$ar_Rows['telephonenumber'][0].Substr((isset($ar_Rows[$_POST['Change_telephonenumber']][0])?$ar_Rows[$_POST['Change_telephonenumber']][0]:''),-4), 
									(isset($P_LDAP[$LDAPCurent]['OU'][$UnitCurent]['PrefTelNum'])?$P_LDAP[$LDAPCurent]['OU'][$UnitCurent]['PrefTelNum']:''),
									11
								);
						$ipphone_telephonenumber = array_unique(explode (',',$ipphone_telephonenumber));
						$ArrCur['telephonenumber'] = implode(",",$ipphone_telephonenumber); 
					};
					if (!Empty($_POST['Change_ipphone'])) {
						$ipphone_Temp= 
								phone_format(
									(isset($ar_Rows[$_POST['Change_ipphone']][0])?$ar_Rows[$_POST['Change_ipphone']][0]:'').(isset($ar_Rows['ipphone'][0])?', '.$ar_Rows['ipphone'][0]:''), 
									(isset($P_LDAP[$LDAPCurent]['OU'][$UnitCurent]['PrefIPPhone'])?$P_LDAP[$LDAPCurent]['OU'][$UnitCurent]['PrefIPPhone']:''),
									7
								);
						$ipphone_Temp = array_unique(explode (',',$ipphone_Temp));
						$ArrCur['ipphone'] = implode(",",$ipphone_Temp);
					};
					if (!Empty($_POST['Del_pager'])) 
						$ArrCur['pager'] = ''; 
					Echo '<pre>';
					Echo Print_r($ar_Rows);
					Echo '<br>';
					If (!empty($ArrCur) ) {
						Echo Print_r($ArrCur);
						if (Empty($_POST['TestRun']))
							setData($LC, $ar_Rows['dn'], $ArrCur);
					} 
					Echo '</pre>';
					Echo '=====================================================================================';
				}/**/
				Echo '<br>ВСЁ ГОТОВО';
			};
		?>
	<?php echo base64_decode ('PGRpdiBzdHlsZT0iZm9udC1mYW1pbHk6IHNlcmlmOyBmb250LXNpemU6IDEycHg7IGJhY2tncm91bmQtY29sb3I6IGFsaWNlYmx1ZTsgYm9yZGVyOiAxcHggb3V0c2V0OyBib3R0b206IDVweDsgY3Vyc29yOiBkZWZhdWx0OyBtYXJnaW4tbGVmdDogMHB4OyBwYWRkaW5nOiAzcHggNnB4OyByaWdodDogMjRweDsgcG9zaXRpb246IGZpeGVkOyI+IFBvd2VyZWQgYnkgPGEgZGF0YS10ZXh0PSJwYWdlcy9kZWZhdWx0L2RldGFpbHMucGhwP0lEPU1ESjhmSHg4ZFdaaGZIeDhmRFpqTURreU1USXlZbUl6WW1ZM05EazVZVEV3TWpZd05HWmhNVFk1TVRWbCIgZGF0YS10YXJnZXQ9IiNtb2RhbC13aW5kb3dzIiBkYXRhLXRvZ2dsZT0ibW9kYWwiIGhyZWY9IiIgb25jbGljaz0iU2hvd1VzZXJNb2RhbCh0aGlzKSI+0JHQsNC60LXQtdCyINCU0KAgPC9hPjwvZGl2Pg==');?>
	</body>
</html>